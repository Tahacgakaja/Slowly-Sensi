package com.slowlybypass.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 8, 8)
    private val panel = Color.rgb(28, 28, 28)
    private val green = Color.rgb(52, 211, 105)
    private var expression = ""
    private var userName = "Usuário"
    private var currentFolder: Uri? = null
    private val foundFiles = mutableListOf<Uri>()
    private val history = mutableListOf<String>()
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showCalculator()
    }

    private fun base(title: String): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 18)
            setBackgroundColor(bg)
        }
        val heading = TextView(this).apply {
            text = title
            textSize = 23f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 4, 0, 16)
        }
        root.addView(heading)
        return root
    }

    private fun button(text: String, color: Int = panel, action: () -> Unit): Button {
        return Button(this).apply {
            this.text = text
            textSize = 15f
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(color))
            isAllCaps = false
            setOnClickListener { action() }
        }
    }

    private fun text(text: String, size: Float = 16f): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(Color.WHITE)
            setPadding(8, 10, 8, 10)
        }

    private fun addButton(label: String, color: Int = panel, action: () -> Unit) {
        root.addView(button(label, color, action), LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 54
        ).apply { bottomMargin = 7 })
    }

    private fun showCalculator() {
        base("Calculadora")
        val display = text(if (expression.isBlank()) "0" else expression, 34f).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            minHeight = 100
        }
        root.addView(display)
        val keys = listOf("7","8","9","÷","4","5","6","×","1","2","3","−","0","C","=","+")
        for (rowKeys in keys.chunked(4)) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (key in rowKeys) {
                val color = if (key in listOf("÷","×","−","+")) Color.DKGRAY else if (key == "=") green else panel
                val b = button(key, color) {
                    when (key) {
                        "C" -> expression = ""
                        "=" -> {
                            val result = evaluate(expression)
                            if (result != null) {
                                history.add("$expression = $result")
                                expression = result.toString()
                            } else Toast.makeText(this, "Expressão inválida", Toast.LENGTH_SHORT).show()
                        }
                        else -> expression += when (key) { "÷" -> "/"; "×" -> "*"; "−" -> "-"; else -> key }
                    }
                    showCalculator()
                }
                row.addView(b, LinearLayout.LayoutParams(0, 62, 1f).apply { setMargins(3,3,3,3) })
            }
            root.addView(row)
        }
        addButton("Abrir Slowly Bypass", Color.rgb(35, 80, 55)) { showDashboard() }
        setContentView(root)
    }

    private fun showDashboard() {
        base("Slowly Bypass")
        root.addView(text("Olá, $userName", 25f))
        root.addView(text("Painel pessoal • ferramentas para arquivos acessíveis", 14f))
        addButton("Scanner de arquivos") { pickFolder() }
        addButton("Limpeza de arquivos selecionados") { showFiles() }
        addButton("Shizuku — informações") {
            AlertDialog.Builder(this).setTitle("Shizuku")
                .setMessage("Esta versão ainda não integra a biblioteca Shizuku. Nenhuma permissão Shizuku foi solicitada.")
                .setPositiveButton("OK", null).show()
        }
        addButton("Histórico") {
            AlertDialog.Builder(this).setTitle("Histórico")
                .setMessage(if (history.isEmpty()) "Nenhuma operação registrada nesta sessão." else history.joinToString("\n"))
                .setPositiveButton("Fechar", null).show()
        }
        addButton("Perfil / nome") {
            val input = EditText(this).apply { setText(userName); hint = "Seu nome" }
            AlertDialog.Builder(this).setTitle("Editar perfil").setView(input)
                .setPositiveButton("Salvar") { _, _ -> userName = input.text.toString().ifBlank { "Usuário" }; showDashboard() }
                .setNegativeButton("Cancelar", null).show()
        }
        addButton("Voltar à calculadora") { showCalculator() }
        setContentView(root)
    }

    private fun pickFolder() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        startActivityForResult(intent, 120)
    }

    @Deprecated("Deprecated by Android, kept for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 120 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            currentFolder = uri
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            } catch (_: Exception) {}
            scanFolder(uri)
        }
    }

    private fun scanFolder(tree: Uri) {
        foundFiles.clear()
        try {
            val docId = DocumentsContract.getTreeDocumentId(tree)
            val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            contentResolver.query(childrenUri, arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE
            ), null, null, null)?.use { cursor ->
                while (cursor.moveToNext()) {
                    val id = cursor.getString(0)
                    val mime = cursor.getString(2)
                    if (mime != DocumentsContract.Document.MIME_TYPE_DIR) {
                        foundFiles.add(DocumentsContract.buildDocumentUriUsingTree(tree, id))
                    }
                }
            }
            history.add("Scanner: ${foundFiles.size} arquivo(s) listado(s)")
            showFiles()
        } catch (e: Exception) {
            Toast.makeText(this, "Não foi possível listar essa pasta.", Toast.LENGTH_LONG).show()
        }
    }

    private fun showFiles() {
        base("Arquivos encontrados")
        root.addView(text("Somente arquivos da pasta escolhida. Confira antes de apagar.", 14f))
        if (foundFiles.isEmpty()) root.addView(text("Nenhum arquivo listado. Use Scanner de arquivos para escolher uma pasta."))
        val checks = mutableListOf<Pair<CheckBox, Uri>>()
        for (uri in foundFiles) {
            val name = try {
                contentResolver.query(uri, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) it.getString(0) else uri.lastPathSegment ?: "Arquivo"
                } ?: (uri.lastPathSegment ?: "Arquivo")
            } catch (_: Exception) { uri.lastPathSegment ?: "Arquivo" }
            val cb = CheckBox(this).apply { text = name; setTextColor(Color.WHITE) }
            root.addView(cb)
            checks.add(cb to uri)
        }
        addButton("Apagar selecionados", Color.rgb(150, 35, 35)) {
            val selected = checks.filter { it.first.isChecked }.map { it.second }
            if (selected.isEmpty()) {
                Toast.makeText(this, "Marque pelo menos um arquivo.", Toast.LENGTH_SHORT).show()
            } else {
                AlertDialog.Builder(this).setTitle("Confirmar exclusão")
                    .setMessage("Apagar ${selected.size} arquivo(s)? Essa ação pode ser irreversível.")
                    .setNegativeButton("Cancelar", null)
                    .setPositiveButton("Apagar") { _, _ ->
                        var deleted = 0
                        for (uri in selected) {
                            try { if (DocumentsContract.deleteDocument(contentResolver, uri)) deleted++ } catch (_: Exception) {}
                        }
                        history.add("Exclusão: $deleted de ${selected.size} arquivo(s)")
                        Toast.makeText(this, "Apagados: $deleted", Toast.LENGTH_LONG).show()
                        showFiles()
                    }.show()
            }
        }
        addButton("Voltar ao painel") { showDashboard() }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun evaluate(raw: String): Double? {
        return try {
            val s = raw.replace(" ", "")
            if (!s.matches(Regex("[0-9.+*/-]+"))) return null
            // Basic two-operand calculator, intentionally avoids evaluating arbitrary code.
            val match = Regex("^(-?\\d+(?:\\.\\d+)?)([+*/-])(-?\\d+(?:\\.\\d+)?)$").matchEntire(s) ?: return s.toDoubleOrNull()
            val a = match.groupValues[1].toDouble()
            val op = match.groupValues[2]
            val b = match.groupValues[3].toDouble()
            when (op) {
                "+" -> a + b
                "-" -> a - b
                "*" -> a * b
                "/" -> if (b == 0.0) null else a / b
                else -> null
            }
        } catch (_: Exception) { null }
    }
}
